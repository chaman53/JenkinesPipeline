#! /bin/bash

CLUSTER_NAME="prod-eksprod"

key=$(stat key.json >/dev/null 2>&1)
if [[ $? == 1 ]]; then
  aws iam create-policy --policy-name "AllowExternalDNSUpdates" --policy-document file://policy.json
  POLICY_ARN=$(aws iam list-policies --query 'Policies[?PolicyName==`AllowExternalDNSUpdates`].Arn' --output text)

  aws iam create-user --user-name "external-dns"
  aws iam attach-user-policy --user-name "external-dns" --policy-arn $POLICY_ARN
  aws iam create-access-key --user-name external-dns > key.json
fi

AccessKeyId=$(cat key.json | jq .AccessKey.AccessKeyId | tr -d '"' | tr -d '\n' | base64)
SecretAccessKey=$(cat key.json | jq .AccessKey.SecretAccessKey | tr -d '"' | tr -d '\n' | base64)

kubectl create ns external-dns
A=$SecretAccessKey B=$AccessKeyId yq ".data.aws_secret_access_key=strenv(A) | .data.aws_access_key_id=strenv(B)" < secret.yaml | kubectl apply -f -

cp values.yaml new_values.yaml

CLUSTER_NAME="$CLUSTER_NAME" yq ".txtOwnerId=strenv(CLUSTER_NAME)" < new_values.yaml > new_values.yaml

helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update
helm upgrade -i external-dns bitnami/external-dns -f ./new_values.yaml -n external-dns --create-namespace

rm -rf new_values.yaml